-- seq 시퀀스 생성

CREATE SEQUENCE seq_users_no
INCREMENT BY 1                 
START WITH 1                   
nocache; 


CREATE SEQUENCE seq_dog_no
INCREMENT BY 1                 
START WITH 1                   
nocache; 

CREATE SEQUENCE seq_walkdog_no
INCREMENT BY 1                 
START WITH 1                   
nocache; 

CREATE SEQUENCE seq_coords_no
INCREMENT BY 1                 
START WITH 1                   
nocache; 

CREATE SEQUENCE seq_blog_no
INCREMENT BY 1                 
START WITH 1                   
nocache; 

CREATE SEQUENCE seq_images_no
INCREMENT BY 1                 
START WITH 1                   
nocache; 

CREATE SEQUENCE seq_club_no
INCREMENT BY 1                 
START WITH 1                   
nocache; 

CREATE SEQUENCE seq_clubusers_no
INCREMENT BY 1                 
START WITH 1                   
nocache; 

CREATE SEQUENCE seq_meeting_no
INCREMENT BY 1                 
START WITH 1                   
nocache; 

CREATE SEQUENCE seq_meetinginfo_no
INCREMENT BY 1                 
START WITH 1                   
nocache; 

CREATE SEQUENCE seq_clubboardcategory_no
INCREMENT BY 1                 
START WITH 1                   
nocache; 

CREATE SEQUENCE seq_walkeddog_no
INCREMENT BY 1                 
START WITH 1                   
nocache; 

CREATE SEQUENCE seq_trail_no
INCREMENT BY 1                 
START WITH 1                   
nocache; 

CREATE SEQUENCE seq_trailused_no
INCREMENT BY 1                 
START WITH 1                   
nocache; 

CREATE SEQUENCE seq_trailstar_no
INCREMENT BY 1                 
START WITH 1                   
nocache; 

CREATE SEQUENCE seq_trailcmt_no
INCREMENT BY 1                 
START WITH 1                   
nocache; 


CREATE SEQUENCE seq_trailtag_no
INCREMENT BY 1                 
START WITH 1                   
nocache; 

CREATE SEQUENCE seq_walklogcmt_no
INCREMENT BY 1                 
START WITH 1                   
nocache; 

CREATE SEQUENCE seq_commboard_no
INCREMENT BY 1                 
START WITH 1                   
nocache; 

CREATE SEQUENCE seq_commcmt_no
INCREMENT BY 1                 
START WITH 1                   
nocache; 

CREATE SEQUENCE seq_follow_no
INCREMENT BY 1                 
START WITH 1                   
nocache; 

CREATE SEQUENCE seq_friend_no
INCREMENT BY 1                 
START WITH 1                   
nocache; 

CREATE SEQUENCE seq_clubjoin_no
INCREMENT BY 1                 
START WITH 1                   
nocache; 

CREATE SEQUENCE seq_complaints_no
INCREMENT BY 1                 
START WITH 1                   
nocache; 


CREATE SEQUENCE seq_location_no
INCREMENT BY 1                 
START WITH 1                   
nocache; 

CREATE SEQUENCE seq_clubboard_no
INCREMENT BY 1                 
START WITH 1                   
nocache; 

CREATE SEQUENCE seq_clubcmt_no
INCREMENT BY 1                 
START WITH 1                   
nocache; 


CREATE SEQUENCE seq_userlike_no
INCREMENT BY 1                 
START WITH 1                   
nocache; 






