-- SELECT문 테스트

SELECT * FROM tab;
SELECT * FROM seq;